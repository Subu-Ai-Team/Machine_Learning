#!/usr/bin/env python
# coding: utf-8


import numpy as np
import pandas as pd
import seaborn as sbn
import matplotlib.pyplot as plt

def info(df):
    print("Data Info",df.info())
    
def describe_function(df):
    print("Describe", df.describe().T)
    a= print("Null ?", df.isnull().values.any())
    if a== True:
        b= df.isnull().sum()
        print("Null summary",b )
    else:
        print("You don't have any null values.")  

def first3_and_last3(df):
    print("First 3:" , df.loc[0:2])
    print("Last 3:",df.iloc[0:3])
    

def visualization(dataframe,columns):
    dataframe[columns].hist(grid=True,figsize=(12,8))

def pie_visualization(dataframe,column):
    dataframe[column].value_counts().plot.pie(legend=True,autopct="%1.1f%%")
    


def graph(x,y,df):
    sbn.boxplot(x=x , y=y, data=df)

    plt.figure(figsize=(10,10))
    
    plt.show()

def plotHistogram(degisken):
    """
        Girdi: Değisken / sütun ismi
        Çıktı: İlgili değişkenin histogramı
    """
    plt.figure()
    plt.hist(veri[degisken], bins=85, color = "blue")
    plt.xlabel(degisken)
    plt.ylabel("Frekans")
    plt.title("Veri Sıklığı - {}".format(degisken))
    plt.show()